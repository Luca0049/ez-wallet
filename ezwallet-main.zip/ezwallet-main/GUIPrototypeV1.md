# Graphical User Interface Prototype  - CURRENT

Authors: Gabriele Garodois, Lorenzo Giammarini, Michele Mogavero, Luca Tortore 

Date: 2023/04/20

Version: 1.0


![Alt Text](./imagesDeadline1/gui_v1/img_1.png)
![Alt Text](./imagesDeadline1/gui_v1/img_2.png)
![Alt Text](./imagesDeadline1/gui_v1/img_3.png)
![Alt Text](./imagesDeadline1/gui_v1/img_4.png)
![Alt Text](./imagesDeadline1/gui_v1/img_5.png)
![Alt Text](./imagesDeadline1/gui_v1/img_6.png)
![Alt Text](./imagesDeadline1/gui_v1/img_7.png)
![Alt Text](./imagesDeadline1/gui_v1/img_8.png)
![Alt Text](./imagesDeadline1/gui_v1/img_9.png)
![Alt Text](./imagesDeadline1/gui_v1/img_10.png)
![Alt Text](./imagesDeadline1/gui_v1/img_11.png)
![Alt Text](./imagesDeadline1/gui_v1/img_12.png)
![Alt Text](./imagesDeadline1/gui_v1/img_13.png)
![Alt Text](./imagesDeadline1/gui_v1/img_14.png)
![Alt Text](./imagesDeadline1/gui_v1/img_15.png)
