# EZWallet

EZWallet is a web application designed to help individuals and families keep track of their 
expenses. Users can enter and categorize their expenses, allowing them to quickly see where their 
money is going. EZWallet is a powerful tool for those looking to take control of their finances and 
make informed decisions about their spending.
