# Graphical User Interface Prototype  - FUTURE

Authors: Gabriele Garodois, Lorenzo Giammarini, Michele Mogavero, Luca Tortore

Date: 2023/04/20

Version: 2.0

![Alt Text](./imagesDeadline1/gui_v2/img_1.png)
![Alt Text](./imagesDeadline1/gui_v2/img_2.png)
![Alt Text](./imagesDeadline1/gui_v2/img_3.png)
![Alt Text](./imagesDeadline1/gui_v2/img_4.png)
![Alt Text](./imagesDeadline1/gui_v2/img_5.png)
![Alt Text](./imagesDeadline1/gui_v2/img_6.png)
![Alt Text](./imagesDeadline1/gui_v2/img_7.png)
![Alt Text](./imagesDeadline1/gui_v2/img_8.png)
![Alt Text](./imagesDeadline1/gui_v2/img_9.png)
![Alt Text](./imagesDeadline1/gui_v2/img_10.png)
![Alt Text](./imagesDeadline1/gui_v2/img_11.png)
![Alt Text](./imagesDeadline1/gui_v2/img_12.png)
![Alt Text](./imagesDeadline1/gui_v2/img_13.png)
![Alt Text](./imagesDeadline1/gui_v2/img_14.png)
![Alt Text](./imagesDeadline1/gui_v2/img_15.png)
![Alt Text](./imagesDeadline1/gui_v2/img_15.1.png)
![Alt Text](./imagesDeadline1/gui_v2/img_16.png)
![Alt Text](./imagesDeadline1/gui_v2/img_17.png)
![Alt Text](./imagesDeadline1/gui_v2/img_17.1.png)
![Alt Text](./imagesDeadline1/gui_v2/img_18.png)
![Alt Text](./imagesDeadline1/gui_v2/img_19.png)
![Alt Text](./imagesDeadline1/gui_v2/img_20.png)
![Alt Text](./imagesDeadline1/gui_v2/img_21.png)
![Alt Text](./imagesDeadline1/gui_v2/img_22.png)
![Alt Text](./imagesDeadline1/gui_v2/img_23.png)
![Alt Text](./imagesDeadline1/gui_v2/img_24.png)
![Alt Text](./imagesDeadline1/gui_v2/img_25.png)
![Alt Text](./imagesDeadline1/gui_v2/img_26.png)
![Alt Text](./imagesDeadline1/gui_v2/img_27.png)
![Alt Text](./imagesDeadline1/gui_v2/img_28.png)
![Alt Text](./imagesDeadline1/gui_v2/img_29.png)
